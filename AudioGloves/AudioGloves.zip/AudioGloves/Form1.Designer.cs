﻿namespace AudioGloves
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.LF_label = new System.Windows.Forms.Label();
            this.RF_label = new System.Windows.Forms.Label();
            this.LS_label = new System.Windows.Forms.Label();
            this.LT_label = new System.Windows.Forms.Label();
            this.LL_label = new System.Windows.Forms.Label();
            this.LTH_label = new System.Windows.Forms.Label();
            this.RTH_label = new System.Windows.Forms.Label();
            this.RS_label = new System.Windows.Forms.Label();
            this.RT_label = new System.Windows.Forms.Label();
            this.RL_label = new System.Windows.Forms.Label();
            this.LK_label = new System.Windows.Forms.Label();
            this.LP_label = new System.Windows.Forms.Label();
            this.RP_label = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Enabled = false;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(31, 52);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1327, 779);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // LF_label
            // 
            this.LF_label.AutoSize = true;
            this.LF_label.Location = new System.Drawing.Point(376, 91);
            this.LF_label.Name = "LF_label";
            this.LF_label.Size = new System.Drawing.Size(49, 32);
            this.LF_label.TabIndex = 1;
            this.LF_label.Text = "FF";
            this.LF_label.Visible = false;
            // 
            // RF_label
            // 
            this.RF_label.AutoSize = true;
            this.RF_label.Location = new System.Drawing.Point(968, 91);
            this.RF_label.Name = "RF_label";
            this.RF_label.Size = new System.Drawing.Size(49, 32);
            this.RF_label.TabIndex = 2;
            this.RF_label.Text = "FF";
            this.RF_label.Visible = false;
            // 
            // LS_label
            // 
            this.LS_label.AutoSize = true;
            this.LS_label.Location = new System.Drawing.Point(213, 79);
            this.LS_label.Name = "LS_label";
            this.LS_label.Size = new System.Drawing.Size(51, 32);
            this.LS_label.TabIndex = 3;
            this.LS_label.Text = "SF";
            this.LS_label.Visible = false;
            // 
            // LT_label
            // 
            this.LT_label.AutoSize = true;
            this.LT_label.Location = new System.Drawing.Point(142, 148);
            this.LT_label.Name = "LT_label";
            this.LT_label.Size = new System.Drawing.Size(49, 32);
            this.LT_label.TabIndex = 4;
            this.LT_label.Text = "TF";
            this.LT_label.Visible = false;
            // 
            // LL_label
            // 
            this.LL_label.AutoSize = true;
            this.LL_label.Location = new System.Drawing.Point(35, 315);
            this.LL_label.Name = "LL_label";
            this.LL_label.Size = new System.Drawing.Size(48, 32);
            this.LL_label.TabIndex = 5;
            this.LL_label.Text = "LF";
            this.LL_label.Visible = false;
            // 
            // LTH_label
            // 
            this.LTH_label.AutoSize = true;
            this.LTH_label.Location = new System.Drawing.Point(621, 275);
            this.LTH_label.Name = "LTH_label";
            this.LTH_label.Size = new System.Drawing.Size(32, 32);
            this.LTH_label.TabIndex = 6;
            this.LTH_label.Text = "T";
            this.LTH_label.Visible = false;
            // 
            // RTH_label
            // 
            this.RTH_label.AutoSize = true;
            this.RTH_label.Location = new System.Drawing.Point(730, 275);
            this.RTH_label.Name = "RTH_label";
            this.RTH_label.Size = new System.Drawing.Size(32, 32);
            this.RTH_label.TabIndex = 7;
            this.RTH_label.Text = "T";
            this.RTH_label.Visible = false;
            // 
            // RS_label
            // 
            this.RS_label.AutoSize = true;
            this.RS_label.Location = new System.Drawing.Point(1123, 79);
            this.RS_label.Name = "RS_label";
            this.RS_label.Size = new System.Drawing.Size(51, 32);
            this.RS_label.TabIndex = 8;
            this.RS_label.Text = "SF";
            this.RS_label.Visible = false;
            // 
            // RT_label
            // 
            this.RT_label.AutoSize = true;
            this.RT_label.Location = new System.Drawing.Point(1194, 139);
            this.RT_label.Name = "RT_label";
            this.RT_label.Size = new System.Drawing.Size(49, 32);
            this.RT_label.TabIndex = 9;
            this.RT_label.Text = "TF";
            this.RT_label.Visible = false;
            // 
            // RL_label
            // 
            this.RL_label.AutoSize = true;
            this.RL_label.Location = new System.Drawing.Point(1301, 315);
            this.RL_label.Name = "RL_label";
            this.RL_label.Size = new System.Drawing.Size(48, 32);
            this.RL_label.TabIndex = 10;
            this.RL_label.Text = "LF";
            this.RL_label.Visible = false;
            // 
            // LK_label
            // 
            this.LK_label.AutoSize = true;
            this.LK_label.Location = new System.Drawing.Point(605, 363);
            this.LK_label.Name = "LK_label";
            this.LK_label.Size = new System.Drawing.Size(34, 32);
            this.LK_label.TabIndex = 11;
            this.LK_label.Text = "K";
            this.LK_label.Visible = false;
            // 
            // LP_label
            // 
            this.LP_label.AutoSize = true;
            this.LP_label.Location = new System.Drawing.Point(392, 570);
            this.LP_label.Name = "LP_label";
            this.LP_label.Size = new System.Drawing.Size(80, 32);
            this.LP_label.TabIndex = 12;
            this.LP_label.Text = "Palm";
            this.LP_label.Visible = false;
            // 
            // RP_label
            // 
            this.RP_label.AutoSize = true;
            this.RP_label.Location = new System.Drawing.Point(923, 570);
            this.RP_label.Name = "RP_label";
            this.RP_label.Size = new System.Drawing.Size(80, 32);
            this.RP_label.TabIndex = 13;
            this.RP_label.Text = "Palm";
            this.RP_label.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(47, 869);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(646, 32);
            this.label1.TabIndex = 14;
            this.label1.Text = "Digital Music Gloves - by Dave Corsie (June 2018)";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1567, 943);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.RP_label);
            this.Controls.Add(this.LP_label);
            this.Controls.Add(this.LK_label);
            this.Controls.Add(this.RL_label);
            this.Controls.Add(this.RT_label);
            this.Controls.Add(this.RS_label);
            this.Controls.Add(this.RTH_label);
            this.Controls.Add(this.LTH_label);
            this.Controls.Add(this.LL_label);
            this.Controls.Add(this.LT_label);
            this.Controls.Add(this.LS_label);
            this.Controls.Add(this.RF_label);
            this.Controls.Add(this.LF_label);
            this.Controls.Add(this.pictureBox1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Audio Gloves";
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyUp);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label LF_label;
        private System.Windows.Forms.Label RF_label;
        private System.Windows.Forms.Label LS_label;
        private System.Windows.Forms.Label LT_label;
        private System.Windows.Forms.Label LL_label;
        private System.Windows.Forms.Label LTH_label;
        private System.Windows.Forms.Label RTH_label;
        private System.Windows.Forms.Label RS_label;
        private System.Windows.Forms.Label RT_label;
        private System.Windows.Forms.Label RL_label;
        private System.Windows.Forms.Label LK_label;
        private System.Windows.Forms.Label LP_label;
        private System.Windows.Forms.Label RP_label;
        private System.Windows.Forms.Label label1;
    }
}

